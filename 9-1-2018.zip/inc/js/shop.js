 jQuery(function($) {
     size = $('.size-choose').text();
     $(document).on('click', '.size-div', function(e) {
         e.preventDefault();
         $('.size-div .text-size-shop').hide();
         $(this).find('.text-size-shop').show();
         size = $(this).find('.text-size-shop').text();
         $(this).find('.text-size-shop').css('background-color', '#d9d9d9');
         $('.size-choose').text(size);
     });
     $('.button-big').on('click', function() {
         $(".cart-button").removeClass('shake_effect');
         setTimeout(function() {
             $(".cart-button").addClass('shake_effect')
         }, 1);
         var img = $(".entry-image-shop img:first").attr('src');
         var title = $(".entry-title").text();
         var price = $(".price-data").text();
         var content = $(".entry-content").text();
         if (size != '') {
         	 $('.error-choose').text('');
         	 $(".cb-counter-label").text(parseInt($(".cb-counter-label").text())+1);
             $(".add-cart-div").html("<div class='production-pre'>" + "<img src='" + img + "' style='width: 5em;'>" + "<div class='production-content-pre'>" + "<div class='title-pre'>" + title + "</div>" + "<div class='price-pre'>" + price + "</div>" + "<div class='content-pre'>" + content + "</div>" + "<div>" +size+"</div>"+"<div class='amount'> x"+parseInt($(".cb-counter-label").text())+"</div>" + "</div>" + "</div>");
         } else {
             $('.error-choose').text('please choose size');
         }
     });
     $('.cart-button').on('click', function() {
         $('.add-cart-div').toggle(200);
     });
 });