<?php

if (!function_exists('shop_menus')):
    function shop_menus()
    {
        $labels = array(
            'name' => 'Shop menu',
            'singular_name' => 'Shop menu',
            'menu_name' => 'Shop menu',
            'name_admin_bar' => 'Shop menu'
        );
        
        $args = array(
            'labels' => $labels,
            'public' => true,
            'show_ui' => true,
            'show_in_menu' => true,
            'show_in_nav_menus' => true,
            'show_in_admin_bar' => true,
            'can_export' => true,
            'has_archive' => true,
            'hierarchical' => false,
            'menu_position' => 26,
            'menu_icon' => 'dashicons-store',
            'supports' => array(
                'title',
                'editor',
                'excerpt',
                'author',
                'thumbnail',
                'comments',
                'revisions',
                'custom-fields'
            ),
            'capability_type' => 'page'
        );
        if (!post_type_exists('shop_production')):
            register_post_type('shop_production', $args);
        endif;
    }
endif;
add_action('init', 'shop_menus');

if (!function_exists('shop_menus_add_category')):
    function shop_menus_add_category()
    {
        register_taxonomy_for_object_type('category', 'shop_production');
    }
endif;
add_action('init', 'shop_menus_add_category');

// GET FEATURED IMAGE
if (!function_exists('shop_menus_get_featured_image')):
    function shop_menus_get_featured_image($post_ID)
    {
        $post_thumbnail_id = get_post_thumbnail_id($post_ID);
        if ($post_thumbnail_id) {
            $post_thumbnail_img = wp_get_attachment_image_src($post_thumbnail_id, 'featured_preview');
            return $post_thumbnail_img[0];
        }
    }
endif;

if (!function_exists('shop_menus_get_price')):
    function shop_menus_get_price($post_ID)
    {
        $price_data = get_post_meta($post_ID, '_price_value_key', true);
        if ($price_data) {
            return $price_data;
        } else {
            return 'null';
        }
    }
endif;

if (!function_exists('shop_menus_columns_head')):
// ADD NEW COLUMN
    function shop_menus_columns_head($defaults)
    {
        $defaults['price']          = 'Price';
        $defaults['featured_image'] = 'Image';
        return $defaults;
    }
endif;
add_filter('manage_edit-shop_production_columns', 'shop_menus_columns_head');

if (!function_exists('shop_menus_columns_content')):
// SHOW THE FEATURED IMAGE
    function shop_menus_columns_content($column_name, $post_ID)
    {
        if ($column_name == 'price') {
            $post_price = shop_menus_get_price($post_ID);
            if ($post_price) {
                echo $post_price . " vnd";
            }
        }
        if ($column_name == 'featured_image') {
            $post_featured_image = shop_menus_get_featured_image($post_ID);
            if ($post_featured_image) {
                echo '<img src="' . $post_featured_image . '" width="100" />';
            }
        }
    }
endif;
add_action('manage_posts_custom_column', 'shop_menus_columns_content', 10, 3);

/* METABOX PRICE */
if (!function_exists('shop_menus_add_meta_box')):
    function shop_menus_add_meta_box()
    {
        add_meta_box('price_box', 'Price', 'shop_menus_price_box_callback', 'shop_production', 'side', 'high');
    }
endif;
add_action('add_meta_boxes', 'shop_menus_add_meta_box');

if (!function_exists('shop_menus_price_box_callback')):
    function shop_menus_price_box_callback($post)
    {
        wp_nonce_field('shop_menus_save_price_data', 'shop_menus_price_meta_box_none');
        $value = get_post_meta($post->ID, '_price_value_key', true);
        echo '<label for="shop_price_field">Price : </label>';
        echo '<input type="text" id="shop_price_field" name="shop_price_field" value="' . esc_attr($value) . '"
            size="24" /> vnd';
    }
endif;

if (!function_exists('shop_menus_save_price_data')):
    function shop_menus_save_price_data($post_id)
    {
        if (!isset($_POST['shop_menus_price_meta_box_none'])) {
            return;
        }
        ;
        
        if (!wp_verify_nonce($_POST['shop_menus_price_meta_box_none'], 'shop_menus_save_price_data')) {
            return;
        }
        ;
        
        if (define('DOING_AUTOSAVE') && DOING_AUTOSAVE) {
            return;
        }
        ;
        
        if (!current_user_can('edit_post', $post_id)) {
            return;
        }
        ;
        
        if (!isset($_POST['shop_price_field'])) {
            return;
        }
        ;
        
        $my_data = sanitize_text_field($_POST['shop_price_field']);
        update_post_meta($post_id, '_price_value_key', $my_data);
    }
endif;
add_action('save_post', 'shop_menus_save_price_data');
/* METABOX PRICE */
/* METABOX SIZE */

if (!function_exists('shop_menus_add_size_meta_box')):
    function shop_menus_add_size_meta_box()
    {
        add_meta_box('size_box', 'Size', 'shop_menus_size_box_callback', 'shop_production', 'side', 'high');
    }
endif;
add_action('add_meta_boxes', 'shop_menus_add_size_meta_box');

if (!function_exists('shop_menus_size_box_callback')):
    function shop_menus_size_box_callback($post)
    {
        wp_nonce_field(basename(__FILE__), 'size_meta_nonce');
        $ids = get_post_meta($post->ID, '_size_value', true);
?>
            <a class="add_field_button button" href="#0" data-uploader-title="Add size(s) to size" data-uploader-button-text="Add size(s)" style="background: #0099F7;
    border-color: #006799;
    color: white;
    text-shadow: 0px 4px 3px rgba(0,0,0,0.4),
             0px 8px 13px rgba(0,0,0,0.1),
             0px 18px 23px rgba(0,0,0,0.1);">ᴀᴅᴅ sɪᴢᴇ</a>
            <a class="free_size_button button" href="#0" style="background: #ff4b1f;      border-color: #bf1a1a;
    font-family: -apple-system,BlinkMacSystemFont,Segoe UI,Roboto,Helvetica Neue,Ubuntu,Arial,sans-serif;
    color: white;
    float: right;
    text-shadow: 0px 4px 3px rgba(0,0,0,0.4),
             0px 8px 13px rgba(0,0,0,0.1),
             0px 18px 23px rgba(0,0,0,0.1);">ғʀᴇᴇ sɪᴢᴇ</a>
            <div class="input_fields_wrap">
<?php
    $j = 0;
    if (is_array($ids) || is_object($ids)):
        foreach ($ids as $key => $value):
            $j++;
        ?>            <div>
<input type="text" id="_size_value" name="_size_value[<?php
            echo $j;
?>]" value="<?php
            echo $value;
?>"
            size="22" />
            <span class="remove_field button" style="float: right;">remove</span>
            </div>
        <?php
    
        endforeach;
    endif;
    echo '</div>';
    ?>

    <?php
    }
endif;

if (!function_exists('shop_menus_save_size_data')):
    function shop_menus_save_size_data($post_id)
    {
    if (!isset($_POST['size_meta_nonce']) || !wp_verify_nonce($_POST['size_meta_nonce'], basename(__FILE__)))
        return;
    if (!current_user_can('edit_post', $post_id))
        return;
    if (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE)
        return;
    if (isset($_POST['_size_value'])) {
        update_post_meta($post_id, '_size_value', $_POST['_size_value']);
    } else {
        delete_post_meta($post_id, '_size_value');
    }
    }
endif;
add_action('save_post', 'shop_menus_save_size_data');
/* METABOX SIZE */


if (!function_exists('gallery_metabox_enqueue')):
function gallery_metabox_enqueue($hook)
{
    if ('post.php' == $hook || 'post-new.php' == $hook) {
        wp_enqueue_script('gallery-metabox', get_stylesheet_directory_uri() . '/inc/js/gatale.js', array(
            'jquery',
            'jquery-ui-sortable'
        ));
    }
}
endif;
add_action('admin_enqueue_scripts', 'gallery_metabox_enqueue');

if (!function_exists('add_gallery_metabox')):
function add_gallery_metabox($post_type)
{
    $types = array(
        'custom-post-type',
        'shop_production'
    );
    if (in_array($post_type, $types)) {
        add_meta_box('gallery-metabox', 'Gallery', 'gallery_meta_callback', $post_type, 'normal', 'high');
    }
}
endif;
add_action('add_meta_boxes', 'add_gallery_metabox');

if (!function_exists('gallery_meta_callback')):
function gallery_meta_callback($post)
{
    wp_nonce_field(basename(__FILE__), 'gallery_meta_nonce');
    $ids = get_post_meta($post->ID, 'vdw_gallery_id', true);
?>
        <table class="form-table">
          <tr><td>
            <a class="gallery-add button" href="#" data-uploader-title="Add image(s) to gallery" data-uploader-button-text="Add image(s)">Add image(s)</a>
    
            <ul id="gallery-metabox-list" >
            <?php
    if ($ids):
        foreach ($ids as $key => $value):
            $image = wp_get_attachment_image_src($value);
?>

    
              <li style="display: inline-block;">
                <input type="hidden" name="vdw_gallery_id[<?php
            echo $key;
?>]" value="<?php
            echo $value;
?>">
                <img class="image-preview" src="<?php
            echo $image[0];
?>">
                <a class="change-image button button-small" href="#" data-uploader-title="Change image" data-uploader-button-text="Change image" style="display: table-cell;">Change image</a><br>
                <small><a class="remove-image" href="#">Remove image</a></small>
              </li>
    
            <?php
        endforeach;
    endif;
?>
            </ul>
    
          </td></tr>
        </table>
      <?php
}
endif;


function gallery_meta_save($post_id)
{
    if (!isset($_POST['gallery_meta_nonce']) || !wp_verify_nonce($_POST['gallery_meta_nonce'], basename(__FILE__)))
        return;
    if (!current_user_can('edit_post', $post_id))
        return;
    if (defined('DOING_AUTOSAVE') && DOING_AUTOSAVE)
        return;
    if (isset($_POST['vdw_gallery_id'])) {
        update_post_meta($post_id, 'vdw_gallery_id', $_POST['vdw_gallery_id']);
    } else {
        delete_post_meta($post_id, 'vdw_gallery_id');
    }
}
add_action('save_post', 'gallery_meta_save');
?>