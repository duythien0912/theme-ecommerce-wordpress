<?php
/*
Template Name: shop cart
*/

/**
 * Template part for displaying posts
 *
 * @link https://codex.wordpress.org/Template_Hierarchy
 *
 * @package WordPress
 * @subpackage Twenty_Seventeen
 * @since 1.0
 * @version 1.2
 */

get_header(); ?>
<div class="wapper-cart">
<div class="cart-page">
</div>
<div class="cart-caculate">
	<table class="table-cart-page">
	<tr>
		<th class="order-items-total">Tổng số sản phẩm:</th>
		<td class="order-items-total">1.199.000 VND</td>
	</tr>
	<tr>
		<th class="order-delivery-costs">Chi phí giao hàng ước tính:</th>
		<td class="order-delivery-costs">0 VND</td>
	</tr>
	<tr>
		<th class="order-total">Tổng:</th>
		<td class="order-total">1.199.000 VND</td>
	</tr>
	<tr>
		<td colspan="2" class="order-vat-costs"><div>* Bao gồm thuế VAT</div></td>
	</tr>
	</table>			
</div>
<div class="btn-return-next-cart">
<button class="btn-return-cart button button-primaryB button-big"><span>Tiếp tục mua sắm</span></button>
<button class="btn-next-cart button button-primaryB button-big"><span>Tiếp tục</span></button>
</div>
<div class="adress-page">
	<div class="ship-cart">
		<div class="logo-ship">
		<svg viewBox="0 0 32 32">
          <g filter="">
            <use xmlns:xlink="http://www.w3.org/1999/xlink" xlink:href="#package">
            	<g id="package" data-iconmelon="e-commerce icons:de2d76203b2448ee25bda0d82fa73c00">
				    <path d="M31.666,7.132l0.028-0.014L16.191,0L0.264,7.285l0.027,0.013v17.39l15.094,7.266V32l0.05-0.023l0.012,0.006l0.006-0.013
					l16.283-7.442V7.132H31.666z M16.191,1.415l12.553,5.73l-3.352,1.604L12.535,3.088L16.191,1.415z M1.669,23.879V7.887l13.993,6.388
					l0.006,16.256L1.669,23.879z M3.202,7.285L8.223,5.06l12.553,5.897l-4.592,2.195L3.202,7.285z M30.358,23.698l-13.307,6.294
					l0.019-15.722l4.873-2.396l0.031,7.692l4.169-2.288V9.777l4.215-2.062V23.698z">
					</path>
			  </g>
            </use>
          </g>
        </svg>
        </div>
        <div class="content-ship"><span>Ship it</span></div>
        <div class="form-addres">
        	<ul class="formControls">
        		<li class="formControl">
	        	<label for="firstName" class="labelLeft">
					 Tên <em class="required">*</em>
				</label>
	        	<input type="text" name="">
	        	</li>
	        	<li class="formControl">
	        	<label for="firstName" class="labelLeft">
					 Họ <em class="required">*</em>
				</label>
	        	<input type="text" name="">
	        	</li>
	        	<li class="formControl">
	        	<label for="firstName" class="labelLeft">
					 Tỉnh <em class="required">*</em>
				</label>
	        	<input type="text" name="">
	        	</li>
	        	<li class="formControl">
	        	<label for="firstName" class="labelLeft">
					 Thành phố <em class="required">*</em>
				</label>
	        	<input type="text" name="">
	        	</li>
	        	<li class="formControl">
	        	<label for="firstName" class="labelLeft">
					 Địa chỉ <em class="required">*</em>
				</label>
	        	<input type="text" name="">
	        	</li>
	        	<li class="formControl">
	        	<label for="firstName" class="labelLeft">
					 Điện thoại (di động) <em class="required">*</em>
				</label>
	        	<input type="text" name="">
	        	</li>
        	</ul>
        	<button class="btn-submit-cart button button-primaryB button-big"><span>Tiếp tục</span></button>
        </div>
	</div>
</div>
</div>
<?php get_footer();?>